def quickSortByAge(students):
    if len(students) <= 1:
        return students
    
    pivot = students[0]
    less = [student for student in students[1:] if student[1] <= pivot[1]]
    greater = [student for student in students[1:] if student[1] > pivot[1]]
    
    return quickSortByAge(less) + [pivot] + quickSortByAge(greater)

# Exemple d'utilisation
students = [("Viny", 34), ("Ryan", 43), ("Tity", 31), ("Antony", 27), ("Calvin", 39), ("Lilian", 27), ("Merlin", 19), ("Rachy", 25)]
sorted_students = quickSortByAge(students)
print(sorted_students)
