
def searchByName(name, students):
    # Trier les étudiants par nom
    sorted_students = quickSortByName(students)
    
    # Recherche binaire
    low, high = 0, len(sorted_students) - 1
    while low <= high:
        mid = (low + high) // 2
        mid_name = sorted_students[mid][0]
        
        if mid_name == name:
            return sorted_students[mid][1]  # Retourner l'âge
        elif mid_name < name:
            low = mid + 1
        else:
            high = mid - 1
    
    return None  # Nom non trouvé

# Exemple d'utilisation
students = [("Viny", 34), ("Ryan", 43), ("Tity", 31), ("Antony", 27), ("Calvin", 39), ("Lilian", 27), ("Merlin", 19), ("Rachy", 25)]
name_to_search = "Calvin"
age = searchByName(name_to_search, students)
print(f"L'âge de {name_to_search} est : {age}")
