def printNames(student):
    for student in student:
        print(student[0])


def printRecNames(student, i=0):
    if i < len(student):
        print(student[i][0])
        printRecNames(student, i + 1)

etu = [('Antony',27),('Calvin',39),('Lilian',27),('Merlin',19),('Rachy',25),('Ryan',43),('Tity',34),('Viny', 34)]

printNames(etu)

printRecNames(etu)