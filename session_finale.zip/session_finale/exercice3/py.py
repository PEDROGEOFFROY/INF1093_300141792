def printNames(students):
    for student in students:
        print(student[0])

# Exemple d'utilisation
students = [("Viny", 34), ("Ryan", 43), ("Tity", 31), ("Antony", 27), ("Calvin", 39), ("Lilian", 27), ("Merlin", 19), ("Rachy", 25)]
printNames(students)
def printRecNames(students):
    # Cas de base : si la liste est vide, rien à faire
    if not students:
        return
    
    # Afficher le nom du premier étudiant
    print(students[0][0])
    
    # Appel récursif sur le reste de la liste
    printRecNames(students[1:])

# Exemple d'utilisation
printRecNames(students)
