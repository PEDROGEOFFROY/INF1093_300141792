def quickSortByAge(list):
    if len(list) <= 1:
        return list
    
    pivot = list.pop()
    
    pet = []
    big = []

    for nbr in list:
        if nbr[1] < pivot[1]:  
            pet.append(nbr)
        else:
            big.append(nbr)
    return quickSortByAge(pet) + [pivot] + quickSortByAge(big)
student = [('Viny', 34),('Ryan',43),('Tity',34),('Antony',27),('Calvin',39),('Lilian',27),('Merlin',19),('Rachy',25)]
print("trie:")
print(quickSortByAge(student))