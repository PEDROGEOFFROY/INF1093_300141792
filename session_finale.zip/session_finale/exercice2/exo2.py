def searchByName(tableau, nom):
    start = 0
    enndd = len(tableau) - 1
    while start <= enndd:
        mill = (start + enndd) // 2
        if nom == tableau[mill][0]:  
            return tableau[mill][1]  
        if nom > tableau[mill][0]:
            start = mill + 1
        else:
            enndd = mill - 1
    return "le nom dont vous cherchez l age nest pas dans le tableau"

student = [('Antony',27),('Calvin',39),('Lilian',27),('Merlin',19),('Rachy',25),('Ryan',43),('Tity',34),('Viny', 34)]


age = searchByName(student, 'Rachy')
print(age)