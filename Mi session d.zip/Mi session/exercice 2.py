def build_list():
    """
    Collecte les noms et âges des étudiants jusqu'à ce que l'utilisateur décide d'arrêter.
    
    Returns:
        list: Une liste de tuples contenant les noms et âges des étudiants.
    """
    students = []  # Initialise une liste vide pour stocker les étudiants
    
    while True:
        name = input("Nom: ")
        age = int(input("Age: "))
        students.append((name, age))
        
        cont = input("Ajouter un autre étudiant? (1/0) ")
        if cont == '0':
            break
    
    return students

# Appelle la fonction build_list et affiche la liste des étudiants
student_list = build_list()
print("Liste complète non triée: ", student_list)
