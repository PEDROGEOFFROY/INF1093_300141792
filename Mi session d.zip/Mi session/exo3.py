def switch(liste, i, j):
    """
    Permute les éléments aux indices i et j dans la liste.
    """
    liste[i], liste[j] = liste[j], liste[i]

def bubbleSort(liste):
    """
    Trie la liste par ordre alphabétique des noms en utilisant le tri à bulles.
    Affiche le contenu de la liste après chaque itération.
    """
    n = len(liste)
    for i in range(n):
        for j in range(0, n-i-1):
            if liste[j][0] > liste[j+1][0]:  # Compare les noms
                switch(liste, j, j+1)
        print(f"Iteration {i}: {liste}")

def selectionSort(liste):
    """
    Trie la liste par âge en utilisant le tri par sélection.
    Affiche le contenu de la liste après chaque itération.
    """
    n = len(liste)
    for i in range(n):
        min_idx = i
        for j in range(i+1, n):
            if liste[j][1] < liste[min_idx][1]:  # Compare les âges
                min_idx = j
        switch(liste, i, min_idx)
        print(f"Iteration {i}: {liste}")

# Liste d'exemple
student_list = [('Viny', 34), ('Ryan', 43), ('Tity', 31), ('Antony', 27), ('Calvin', 39), ('Lilian', 27)]

# Test du tri à bulles
print("Tri à bulles:")
bubbleSort(student_list.copy())  # Utiliser une copie pour ne pas modifier la liste originale

# Test du tri par sélection
print("\nTri par sélection:")
selectionSort(student_list.copy())  # Utiliser une copie pour ne pas modifier la liste originale
